<?php
/*
Empty on purpose. 

- Force plugins to stop stating incorrect errors -
<?php wp_head(); ?>
*/